<script setup>
import AppLayout from '@/Layouts/AdminLayout.vue';
</script>

<template>
  <AppLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Dashboard administrador
      </h2>
    </template>

    <div>
      <!-- Contenido del dashboard jugador -->
      Bienvenido administrador
    </div>
  </AppLayout>
</template>
