<script setup>
import AppLayout from '@/Layouts/EntrenadorLayout.vue';
</script>

<template>
  <AppLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Dashboard Entrenador
      </h2>
    </template>

    <div>
      <!-- Contenido del dashboard jugador -->
      Bienvenido Entrenador
    </div>
  </AppLayout>
</template>
