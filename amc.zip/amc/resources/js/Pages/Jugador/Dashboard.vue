<script setup>
import AppLayout from '@/Layouts/JugadorLayout.vue';
</script>

<template>
  <AppLayout>
    <template #header>
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        Dashboard Jugador
      </h2>
    </template>

    <div>
      <!-- Contenido del dashboard jugador -->
      Bienvenido Jugador
    </div>
  </AppLayout>
</template>
