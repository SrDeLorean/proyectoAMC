<script setup>
import { ref, computed } from 'vue'
import { router } from '@inertiajs/vue3'
import Swal from 'sweetalert2'
import AdminLayout from '@/Layouts/AdminLayout.vue'
import BaseTable from '@/Components/Table/DataTable.vue'

const props = defineProps({
  calendarios: Array,
  jornadas: Array,
  temporadas: Array,     // Array de temporadas [{ id, nombre }]
  competencias: Array,   // Array de competencias [{ id, nombre }]
  success: String,
  trashed: Boolean
})

// Estados para filtros
const selectedJornada = ref('')
const selectedTemporada = ref('')
const selectedCompetencia = ref('')

const baseColumns = [
  { label: 'ID', key: 'id' },
  { label: 'Temporada', key: 'temporada_competencia.temporada.nombre' },
  { label: 'Competencia', key: 'temporada_competencia.competencia.nombre' },
  { label: 'Jornada', key: 'jornada' },
  { label: 'Local', key: 'equipo_local.nombre' },
  { label: 'L', key: 'equipo_local.logo' },
  { label: 'V', key: 'equipo_visitante.logo' },
  { label: 'Visitante', key: 'equipo_visitante.nombre' },
  { label: 'Fecha', key: 'fecha' },
  { label: 'Hora', key: 'hora' }
]

const columns = computed(() =>
  props.trashed
    ? [...baseColumns, { label: 'Eliminado el', key: 'deleted_at' }]
    : baseColumns
)

// Función para filtrar calendarios según filtros activos
const filteredCalendarios = computed(() => {
  return props.calendarios.filter(c => {
    const matchJornada = selectedJornada.value
      ? String(c.jornada) === String(selectedJornada.value)
      : true

    const matchTemporada = selectedTemporada.value
      ? String(c.temporada_competencia.temporada.id) === String(selectedTemporada.value)
      : true

    const matchCompetencia = selectedCompetencia.value
      ? String(c.temporada_competencia.competencia.id) === String(selectedCompetencia.value)
      : true

    return matchJornada && matchTemporada && matchCompetencia
  })
})

const actions = computed(() =>
  props.trashed
    ? [
        {
          label: 'Restaurar',
          class: 'text-green-500 hover:text-green-700 transition',
          actionName: 'restore'
        }
      ]
    : [
        {
          label: 'Detalle',
          class: 'text-yellow-400 hover:text-yellow-600 transition',
          actionName: 'show'
        },
        {
          label: 'Editar',
          class: 'text-blue-400 hover:text-blue-600 transition',
          actionName: 'edit'
        },
        {
          label: 'Eliminar',
          class: 'text-red-500 hover:text-red-700 transition',
          actionName: 'delete'
        }
      ]
)

function onTableAction({ actionName, row }) {
  if (actionName === 'edit') {
    router.get(`/calendarios/${row.id}/edit`)
  }
  if (actionName === 'show') {
    router.get(`/calendarios/${row.id}`)
  }
  if (actionName === 'delete') {
    Swal.fire({
      title: `¿Eliminar partido jornada ${row.jornada}?`,
      text: 'Esta acción no se puede deshacer',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e30613',
      cancelButtonColor: '#6b7280',
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar'
    }).then(result => {
      if (result.isConfirmed) {
        router.delete(`/calendarios/${row.id}`)
      }
    })
  }
  if (actionName === 'restore') {
    Swal.fire({
      title: `¿Restaurar partido jornada ${row.jornada}?`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#22c55e',
      cancelButtonColor: '#6b7280',
      confirmButtonText: 'Sí, restaurar',
      cancelButtonText: 'Cancelar'
    }).then(result => {
      if (result.isConfirmed) {
        router.post(`/calendarios/${row.id}/restore`)
      }
    })
  }
}
</script>

<template>
  <AdminLayout>
    <template #title>
      {{ trashed ? 'Partidos Eliminados' : 'Calendario de Partidos' }}
    </template>

    <div class="p-6 space-y-6">
      <div v-if="success" class="p-3 bg-green-600 text-white rounded shadow">
        {{ success }}
      </div>

      <div class="flex justify-between items-center">
        <h1 class="text-2xl font-bold text-white">
          {{ trashed ? 'Partidos Eliminados' : 'Calendario de Partidos' }}
        </h1>
        <div class="flex gap-3">
          <template v-if="trashed">
            <a
              href="/calendarios"
              class="bg-gray-700 hover:bg-gray-800 text-white px-4 py-2 rounded transition"
            >
              ← Volver a activos
            </a>
          </template>
          <template v-else>
            <a
              href="/calendarios/trashed"
              class="bg-gray-700 hover:bg-gray-800 text-white px-4 py-2 rounded transition"
            >
              🗑️ Ver Eliminados
            </a>
          </template>
        </div>
      </div>

      <!-- Filtros -->
      <div class="flex gap-6 mb-4 flex-wrap">
        <div>
          <label for="filtro-temporada" class="block mb-1 text-white font-semibold">
            Filtrar por Temporada:
          </label>
          <select
            id="filtro-temporada"
            v-model="selectedTemporada"
            class="bg-gray-800 text-white rounded px-3 py-2 min-w-[180px]"
          >
            <option value="">Todas las temporadas</option>
            <option
              v-for="temporada in temporadas"
              :key="temporada.id"
              :value="temporada.id"
            >
              {{ temporada.nombre }}
            </option>
          </select>
        </div>

        <div>
          <label for="filtro-competencia" class="block mb-1 text-white font-semibold">
            Filtrar por Competencia:
          </label>
          <select
            id="filtro-competencia"
            v-model="selectedCompetencia"
            class="bg-gray-800 text-white rounded px-3 py-2 min-w-[180px]"
          >
            <option value="">Todas las competencias</option>
            <option
              v-for="competencia in competencias"
              :key="competencia.id"
              :value="competencia.id"
            >
              {{ competencia.nombre }}
            </option>
          </select>
        </div>

        <div>
          <label for="filtro-jornada" class="block mb-1 text-white font-semibold">
            Filtrar por Jornada:
          </label>
          <select
            id="filtro-jornada"
            v-model="selectedJornada"
            class="bg-gray-800 text-white rounded px-3 py-2 min-w-[140px]"
          >
            <option value="">Todas las jornadas</option>
            <option v-for="j in jornadas" :key="j" :value="j">
              Jornada {{ j }}
            </option>
          </select>
        </div>
      </div>

      <!-- Tabla filtrada -->
      <BaseTable
        :columns="columns"
        :rows="filteredCalendarios"
        :actions="actions"
        @action="onTableAction"
      />
    </div>
  </AdminLayout>
</template>
