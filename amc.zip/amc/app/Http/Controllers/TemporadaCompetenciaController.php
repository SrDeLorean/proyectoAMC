<?php

namespace App\Http\Controllers;

use App\Models\TemporadaCompetencia;
use App\Models\Temporada;
use App\Models\Competencia;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Session;
use App\Models\TemporadaEquipo;

class TemporadaCompetenciaController extends Controller
{
    public function index()
    {
        $temporadaCompetencias = TemporadaCompetencia::with(['temporada', 'competencia'])->paginate(15);

        return Inertia::render('TemporadaCompetencias/Index', [
            'temporadaCompetencias' => $temporadaCompetencias,
            'success' => session('success'),
        ]);
    }

    public function show(TemporadaCompetencia $temporadaCompetencia)
    {
        $temporadaCompetencia->load(['temporada', 'competencia']);

        $equipos = $temporadaCompetencia->equipos()->with('equipo')->get();

        return Inertia::render('TemporadaCompetencias/Show', [
            'temporadaCompetencia' => $temporadaCompetencia,
            'equipos' => $equipos,
        ]);
    }


    public function create()
    {
        // Traemos temporadas y competencias para los selects
        $temporadas = Temporada::all();
        $competencias = Competencia::all();

        return Inertia::render('TemporadaCompetencias/Create', [
            'temporadas' => $temporadas,
            'competencias' => $competencias,
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:255',
            'id_temporada' => 'required|exists:temporadas,id',
            'id_competencia' => 'required|exists:competencias,id',
            'fecha_inicio' => 'nullable|date',
            'fecha_termino' => 'nullable|date|after_or_equal:fecha_inicio',
        ]);

        TemporadaCompetencia::create($validated);

        return redirect()
            ->route('temporada-competencias.index')
            ->with('success', 'TemporadaCompetencia creada correctamente.');
    }

    public function edit(TemporadaCompetencia $temporadaCompetencia)
    {
        $temporadas = Temporada::all();
        $competencias = Competencia::all();

        return Inertia::render('TemporadaCompetencias/Edit', [
            'temporadaCompetencia' => [
                'id' => $temporadaCompetencia->id,
                'nombre' => $temporadaCompetencia->nombre,
                'id_temporada' => $temporadaCompetencia->id_temporada,
                'id_competencia' => $temporadaCompetencia->id_competencia,
                'fecha_inicio' => $temporadaCompetencia->fecha_inicio?->format('Y-m-d'),
                'fecha_termino' => $temporadaCompetencia->fecha_termino?->format('Y-m-d'),
            ],
            'temporadas' => $temporadas,
            'competencias' => $competencias,
        ]);
    }

    public function update(Request $request, TemporadaCompetencia $temporadaCompetencia)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:255',
            'id_temporada' => 'required|exists:temporadas,id',
            'id_competencia' => 'required|exists:competencias,id',
            'fecha_inicio' => 'nullable|date',
            'fecha_termino' => 'nullable|date|after_or_equal:fecha_inicio',
        ]);

        $temporadaCompetencia->update($validated);

        Session::flash('success', 'TemporadaCompetencia actualizada correctamente.');

        return redirect()->route('temporada-competencias.index');
    }

    public function destroy(TemporadaCompetencia $temporadaCompetencia)
    {
        $temporadaCompetencia->delete();

        return redirect()
            ->route('temporada-competencias.index')
            ->with('success', 'TemporadaCompetencia eliminada correctamente.');
    }

    public function trashed()
    {
        $temporadaCompetencias = TemporadaCompetencia::onlyTrashed()->with(['temporada', 'competencia'])->get();

        return Inertia::render('TemporadaCompetencias/Trashed', [
            'temporadaCompetencias' => $temporadaCompetencias,
            'success' => session('success'),
        ]);
    }

    public function restore($id)
    {
        $temporadaCompetencia = TemporadaCompetencia::onlyTrashed()->findOrFail($id);
        $temporadaCompetencia->restore();

        return redirect()
            ->route('temporada-competencias.trashed')
            ->with('success', 'TemporadaCompetencia restaurada correctamente.');
    }


}
